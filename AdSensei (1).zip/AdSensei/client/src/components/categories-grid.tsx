import { useQuery } from "@tanstack/react-query";
import { Laptop, Car, Home, Shirt, Dumbbell, Briefcase, Wrench, Book } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import type { Category } from "@shared/schema";

interface CategoriesGridProps {
  onCategorySelect: (categoryId: string) => void;
}

const iconMap: Record<string, React.ComponentType<any>> = {
  laptop: Laptop,
  car: Car,
  home: Home,
  shirt: Shirt,
  dumbbell: Dumbbell,
  briefcase: Briefcase,
  wrench: Wrench,
  book: Book,
};

export default function CategoriesGrid({ onCategorySelect }: CategoriesGridProps) {
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  const { t } = useLanguage();

  if (isLoading) {
    return (
      <section className="py-12 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-2xl font-bold text-center mb-8">{t.popularCategories}</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-card p-4 rounded-xl text-center animate-pulse">
                <div className="w-12 h-12 mx-auto mb-3 bg-muted rounded-full"></div>
                <div className="h-4 bg-muted rounded w-16 mx-auto"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h3 className="text-2xl font-bold text-center mb-8">{t.popularCategories}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {categories.map((category) => {
            const IconComponent = iconMap[category.icon] || Laptop;
            return (
              <div
                key={category.id}
                onClick={() => onCategorySelect(category.id)}
                className="bg-card p-4 rounded-xl text-center card-hover cursor-pointer"
                data-testid={`category-${category.id}`}
              >
                <div className="w-12 h-12 mx-auto mb-3 gradient-bg rounded-full flex items-center justify-center">
                  <IconComponent className="text-primary-foreground w-6 h-6" />
                </div>
                <span className="text-sm font-medium">{category.name}</span>
                <div className="text-xs text-muted-foreground mt-1">
                  {category.adCount} ads
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
