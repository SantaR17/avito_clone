import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageSwitcher from "./language-switcher";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const { t } = useLanguage();
  
  if (!isOpen) return null;

  return (
    <div className="md:hidden fixed inset-y-0 left-0 w-64 bg-card shadow-lg z-50 mobile-menu open">
      <div className="p-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold">{t.language}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-menu">
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="mb-4">
          <LanguageSwitcher />
        </div>
        
        <nav className="space-y-4">
          <Link href="/" className="block text-muted-foreground hover:text-foreground" onClick={onClose}>
            {t.home}
          </Link>
          <Link href="/profile" className="block text-muted-foreground hover:text-foreground" onClick={onClose}>
            {t.myAds}
          </Link>
          <a href="#" className="block text-muted-foreground hover:text-foreground">
            {t.help}
          </a>
          <hr className="border-border" />
          <Link href="/login" className="block text-muted-foreground hover:text-foreground" onClick={onClose}>
            {t.login}
          </Link>
          <Link href="/register" className="block text-muted-foreground hover:text-foreground" onClick={onClose}>
            {t.register}
          </Link>
        </nav>
      </div>
    </div>
  );
}
