import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Store, Plus, UserCircle, Menu, X, Settings } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageSwitcher from "./language-switcher";
import MobileMenu from "./mobile-menu";

export default function Navbar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { t } = useLanguage();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      <header className="bg-card shadow-sm border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-4" data-testid="link-home">
              <div className="gradient-bg p-2 rounded-lg">
                <Store className="text-primary-foreground text-xl" />
              </div>
              <h1 className="text-xl font-bold text-foreground">ClassiMarket</h1>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <Link 
                href="/" 
                className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/' ? 'text-foreground font-medium' : ''}`}
                data-testid="link-categories"
              >
                {t.home}
              </Link>
              <Link 
                href="/profile" 
                className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/profile' ? 'text-foreground font-medium' : ''}`}
                data-testid="link-my-ads"
              >
                {t.myAds}
              </Link>
              <Link 
                href="/admin" 
                className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/admin' ? 'text-foreground font-medium' : ''}`}
                data-testid="link-admin"
              >
                Admin
              </Link>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                {t.help}
              </a>
            </nav>

            {/* User Actions */}
            <div className="flex items-center space-x-4">
              <Link href="/post-ad" data-testid="button-post-ad">
                <Button className="gradient-bg text-primary-foreground hover:opacity-90 transition-opacity">
                  <Plus className="w-4 h-4 mr-2" />
                  {t.postAd}
                </Button>
              </Link>
              
              <LanguageSwitcher />
              
              <Link href="/login" className="hidden md:block" data-testid="button-login">
                <Button variant="ghost" size="icon">
                  <UserCircle className="h-6 w-6" />
                </Button>
              </Link>
              
              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={toggleMobileMenu}
                data-testid="button-mobile-menu"
              >
                {isMobileMenuOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
    </>
  );
}
