import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MapPin, Eye } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Ad } from "@shared/schema";

interface AdCardProps {
  ad: Ad;
  userId?: string;
}

export default function AdCard({ ad, userId }: AdCardProps) {
  const [isFavorited, setIsFavorited] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      if (!userId) {
        throw new Error("Please login to save favorites");
      }
      
      if (isFavorited) {
        await apiRequest("DELETE", `/api/favorites/${userId}/${ad.id}`);
        return false;
      } else {
        await apiRequest("POST", "/api/favorites", { userId, adId: ad.id });
        return true;
      }
    },
    onSuccess: (newFavoriteState) => {
      setIsFavorited(newFavoriteState);
      toast({
        title: newFavoriteState ? "Added to favorites" : "Removed from favorites",
        description: newFavoriteState ? "Ad saved to your favorites" : "Ad removed from favorites",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(price));
  };

  const getTimeAgo = (date: Date | null) => {
    if (!date) return "Recently";
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    favoriteMutation.mutate();
  };

  return (
    <Card className="card-hover cursor-pointer" data-testid={`card-ad-${ad.id}`}>
      <Link href={`/ad/${ad.id}`}>
        <div className="relative">
          {ad.images && ad.images[0] && (
            <img 
              src={ad.images[0]} 
              alt={ad.title}
              className="w-full h-48 object-cover rounded-t-xl"
            />
          )}
          {(!ad.images || !ad.images[0]) && (
            <div className="w-full h-48 bg-muted rounded-t-xl flex items-center justify-center">
              <span className="text-muted-foreground">No image</span>
            </div>
          )}
          {ad.featured && (
            <div className="absolute top-2 left-2 bg-accent text-accent-foreground px-2 py-1 rounded text-xs font-medium">
              Featured
            </div>
          )}
        </div>
        
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl font-bold text-primary" data-testid={`text-price-${ad.id}`}>
              {formatPrice(ad.price)}
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleFavoriteClick}
              disabled={favoriteMutation.isPending}
              data-testid={`button-favorite-${ad.id}`}
            >
              <Heart className={`w-4 h-4 ${isFavorited ? 'fill-destructive text-destructive' : 'text-muted-foreground hover:text-destructive'}`} />
            </Button>
          </div>
          
          <h4 className="font-semibold mb-2 line-clamp-1" data-testid={`text-title-${ad.id}`}>
            {ad.title}
          </h4>
          
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {ad.description}
          </p>
          
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="flex items-center">
              <MapPin className="w-3 h-3 mr-1" />
              {ad.location}
            </span>
            <span className="flex items-center space-x-2">
              <span className="flex items-center">
                <Eye className="w-3 h-3 mr-1" />
                {ad.views}
              </span>
              <span>{getTimeAgo(ad.createdAt)}</span>
            </span>
          </div>
        </CardContent>
      </Link>
    </Card>
  );
}
