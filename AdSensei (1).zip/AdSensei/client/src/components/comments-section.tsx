import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageCircle, Reply, Trash2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { apiRequest } from "@/lib/queryClient";
import type { CommentWithUser } from "@shared/schema";

interface CommentsSectionProps {
  adId: string;
}

interface CommentItemProps {
  comment: CommentWithUser;
  adId: string;
  onReply: (parentId: string) => void;
  level?: number;
}

function CommentItem({ comment, adId, onReply, level = 0 }: CommentItemProps) {
  const { t } = useLanguage();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: (commentId: string) => apiRequest(`/api/comments/${commentId}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ads", adId, "comments"] });
    },
  });

  const handleDelete = () => {
    if (window.confirm(t.confirmDeleteComment || "Are you sure you want to delete this comment?")) {
      deleteMutation.mutate(comment.id);
    }
  };

  return (
    <div className={`${level > 0 ? "ml-8 mt-4" : "mb-4"}`}>
      <Card>
        <CardContent className="pt-4">
          <div className="flex items-start space-x-3">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="text-xs">
                {comment.user.avatar || comment.user.fullName.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-2">
                <span className="font-semibold text-sm">{comment.user.fullName}</span>
                <span className="text-xs text-muted-foreground">
                  @{comment.user.username}
                </span>
                <span className="text-xs text-muted-foreground">
                  {comment.createdAt ? new Date(comment.createdAt).toLocaleDateString() : ""}
                </span>
              </div>
              <p className="text-sm text-foreground mb-3">{comment.content}</p>
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onReply(comment.id)}
                  className="text-xs"
                  data-testid={`button-reply-${comment.id}`}
                >
                  <Reply className="w-3 h-3 mr-1" />
                  {t.reply || "Reply"}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDelete}
                  className="text-xs text-destructive"
                  disabled={deleteMutation.isPending}
                  data-testid={`button-delete-${comment.id}`}
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  {t.delete || "Delete"}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Replies */}
      {comment.replies && comment.replies.length > 0 && (
        <div className="mt-3">
          {comment.replies.map((reply) => (
            <CommentItem
              key={reply.id}
              comment={reply}
              adId={adId}
              onReply={onReply}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function CommentsSection({ adId }: CommentsSectionProps) {
  const [newComment, setNewComment] = useState("");
  const [replyToId, setReplyToId] = useState<string | null>(null);
  const { t } = useLanguage();
  const queryClient = useQueryClient();

  const { data: comments = [], isLoading } = useQuery<CommentWithUser[]>({
    queryKey: ["/api/ads", adId, "comments"],
    queryFn: async () => {
      const response = await fetch(`/api/ads/${adId}/comments`);
      if (!response.ok) throw new Error("Failed to fetch comments");
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: { content: string; parentId?: string }) => 
      apiRequest(`/api/ads/${adId}/comments`, "POST", data),
    onSuccess: () => {
      setNewComment("");
      setReplyToId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/ads", adId, "comments"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    createMutation.mutate({
      content: newComment,
      parentId: replyToId || undefined,
    });
  };

  const handleReply = (parentId: string) => {
    setReplyToId(parentId);
    // Focus on textarea when replying
    const textarea = document.querySelector('textarea[data-testid="textarea-comment"]') as HTMLTextAreaElement;
    if (textarea) {
      textarea.focus();
    }
  };

  return (
    <div className="mt-8">
      <div className="flex items-center space-x-2 mb-6">
        <MessageCircle className="w-5 h-5" />
        <h3 className="text-xl font-semibold">
          {t.comments || "Comments"} ({comments.length})
        </h3>
      </div>

      {/* Comment Form */}
      <Card className="mb-6">
        <CardContent className="pt-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            {replyToId && (
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Reply className="w-4 h-4" />
                <span>{t.replyingToComment || "Replying to comment"}</span>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setReplyToId(null)}
                  className="text-xs"
                >
                  {t.cancel || "Cancel"}
                </Button>
              </div>
            )}
            <Textarea
              placeholder={t.writeComment || "Write a comment..."}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              rows={3}
              data-testid="textarea-comment"
            />
            <div className="flex justify-end">
              <Button
                type="submit"
                disabled={!newComment.trim() || createMutation.isPending}
                data-testid="button-post-comment"
              >
                {createMutation.isPending
                  ? (t.postingComment || "Posting...")
                  : (t.postComment || "Post Comment")
                }
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Comments List */}
      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="pt-4">
                <div className="animate-pulse">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-8 h-8 bg-muted rounded-full"></div>
                    <div className="space-y-1">
                      <div className="h-3 bg-muted rounded w-24"></div>
                      <div className="h-2 bg-muted rounded w-16"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded w-full"></div>
                    <div className="h-3 bg-muted rounded w-3/4"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : comments.length === 0 ? (
        <div className="text-center py-8">
          <MessageCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">
            {t.noComments || "No comments yet. Be the first to comment!"}
          </p>
        </div>
      ) : (
        <div>
          {comments.map((comment) => (
            <CommentItem
              key={comment.id}
              comment={comment}
              adId={adId}
              onReply={handleReply}
            />
          ))}
        </div>
      )}
    </div>
  );
}