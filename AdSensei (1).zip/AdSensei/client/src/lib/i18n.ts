export type Language = 'en' | 'ru';

export interface Translations {
  // Navigation
  home: string;
  myAds: string;
  help: string;
  postAd: string;
  login: string;
  register: string;
  profile: string;
  
  // Hero section
  heroTitle: string;
  heroSubtitle: string;
  searchPlaceholder: string;
  allCategories: string;
  locationPlaceholder: string;
  searchButton: string;
  
  // Categories
  popularCategories: string;
  electronics: string;
  vehicles: string;
  homeGarden: string;
  fashion: string;
  sportsRecreation: string;
  jobs: string;
  services: string;
  booksEducation: string;
  
  // Ads
  featuredAds: string;
  searchResults: string;
  noAdsFound: string;
  adjustSearchCriteria: string;
  loadMore: string;
  views: string;
  ago: string;
  justNow: string;
  hoursAgo: string;
  daysAgo: string;
  recently: string;
  
  // Ad details
  backToListings: string;
  noImage: string;
  share: string;
  callSeller: string;
  message: string;
  description: string;
  details: string;
  condition: string;
  location: string;
  posted: string;
  sellerInformation: string;
  memberSince: string;
  reviews: string;
  
  // Post ad
  postYourAd: string;
  adTitle: string;
  enterTitle: string;
  category: string;
  selectCategory: string;
  price: string;
  selectCondition: string;
  enterDescription: string;
  photos: string;
  dragDropPhotos: string;
  chooseFiles: string;
  enterLocation: string;
  agreeToTerms: string;
  termsOfService: string;
  privacyPolicy: string;
  cancel: string;
  postingAd: string;
  
  // Auth
  signIn: string;
  createAccount: string;
  continueWithGoogle: string;
  continueWithFacebook: string;
  or: string;
  email: string;
  password: string;
  confirmPassword: string;
  fullName: string;
  username: string;
  rememberMe: string;
  forgotPassword: string;
  signingIn: string;
  dontHaveAccount: string;
  signUp: string;
  alreadyHaveAccount: string;
  creatingAccount: string;
  enterEmail: string;
  enterPassword: string;
  createPassword: string;
  confirmYourPassword: string;
  enterFullName: string;
  chooseUsername: string;
  
  // Profile
  editProfile: string;
  activeAds: string;
  totalViews: string;
  favorites: string;
  noAdsPosted: string;
  startSelling: string;
  postFirstAd: string;
  noFavorites: string;
  saveAdsHere: string;
  browseAds: string;
  active: string;
  inactive: string;
  
  // Conditions
  new: string;
  likeNew: string;
  excellent: string;
  good: string;
  fair: string;
  
  // Sort options
  sortByLatest: string;
  priceLowToHigh: string;
  priceHighToLow: string;
  mostPopular: string;
  
  // CTA
  gotSomethingToSell: string;
  postAdCTA: string;
  postAdNow: string;
  
  // Footer
  trustedMarketplace: string;
  forBuyers: string;
  howToBuy: string;
  safetyTips: string;
  paymentMethods: string;
  forSellers: string;
  howToSell: string;
  pricingGuide: string;
  proFeatures: string;
  support: string;
  helpCenter: string;
  contactUs: string;
  reportIssue: string;
  allRightsReserved: string;
  cookiePolicy: string;
  
  // Messages
  addedToFavorites: string;
  removedFromFavorites: string;
  adSavedToFavorites: string;
  adRemovedFromFavorites: string;
  error: string;
  success: string;
  adPostedSuccessfully: string;
  welcomeBack: string;
  loginSuccessful: string;
  loginFailed: string;
  accountCreated: string;
  accountCreatedSuccessfully: string;
  registrationFailed: string;
  comingSoon: string;
  
  // Comments
  comments: string;
  writeComment: string;
  postComment: string;
  postingComment: string;
  reply: string;
  delete: string;
  replyingToComment: string;
  noComments: string;
  confirmDeleteComment: string;
  
  // Language
  language: string;
  english: string;
  russian: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    // Navigation
    home: 'Home',
    myAds: 'My Ads',
    help: 'Help',
    postAd: 'Post Ad',
    login: 'Login',
    register: 'Register',
    profile: 'Profile',
    
    // Hero section
    heroTitle: 'Find Everything You Need',
    heroSubtitle: 'Buy and sell with confidence in your local community',
    searchPlaceholder: 'What are you looking for?',
    allCategories: 'All Categories',
    locationPlaceholder: 'Location',
    searchButton: 'Search',
    
    // Categories
    popularCategories: 'Popular Categories',
    electronics: 'Electronics',
    vehicles: 'Vehicles',
    homeGarden: 'Home & Garden',
    fashion: 'Fashion',
    sportsRecreation: 'Sports & Recreation',
    jobs: 'Jobs',
    services: 'Services',
    booksEducation: 'Books & Education',
    
    // Ads
    featuredAds: 'Featured Ads',
    searchResults: 'Search Results',
    noAdsFound: 'No ads found',
    adjustSearchCriteria: 'Try adjusting your search criteria',
    loadMore: 'Load More Ads',
    views: 'views',
    ago: 'ago',
    justNow: 'Just now',
    hoursAgo: 'hours ago',
    daysAgo: 'days ago',
    recently: 'Recently',
    
    // Ad details
    backToListings: 'Back to listings',
    noImage: 'No image available',
    share: 'Share',
    callSeller: 'Call Seller',
    message: 'Message',
    description: 'Description',
    details: 'Details',
    condition: 'Condition',
    location: 'Location',
    posted: 'Posted',
    sellerInformation: 'Seller Information',
    memberSince: 'Member since',
    reviews: 'reviews',
    
    // Post ad
    postYourAd: 'Post Your Ad',
    adTitle: 'Ad Title',
    enterTitle: 'Enter a descriptive title',
    category: 'Category',
    selectCategory: 'Select a category',
    price: 'Price',
    selectCondition: 'Select condition',
    enterDescription: 'Describe your item in detail...',
    photos: 'Photos',
    dragDropPhotos: 'Drag and drop photos here or click to browse',
    chooseFiles: 'Choose Files',
    enterLocation: 'Enter your location',
    agreeToTerms: 'I agree to the',
    termsOfService: 'Terms of Service',
    privacyPolicy: 'Privacy Policy',
    cancel: 'Cancel',
    postingAd: 'Posting...',
    
    // Auth
    signIn: 'Sign In',
    createAccount: 'Create Account',
    continueWithGoogle: 'Continue with Google',
    continueWithFacebook: 'Continue with Facebook',
    or: 'or',
    email: 'Email',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    fullName: 'Full Name',
    username: 'Username',
    rememberMe: 'Remember me',
    forgotPassword: 'Forgot password?',
    signingIn: 'Signing in...',
    dontHaveAccount: "Don't have an account?",
    signUp: 'Sign up',
    alreadyHaveAccount: 'Already have an account?',
    creatingAccount: 'Creating account...',
    enterEmail: 'Enter your email',
    enterPassword: 'Enter your password',
    createPassword: 'Create a password',
    confirmYourPassword: 'Confirm your password',
    enterFullName: 'Enter your full name',
    chooseUsername: 'Choose a username',
    
    // Profile
    editProfile: 'Edit Profile',
    activeAds: 'Active Ads',
    totalViews: 'Total Views',
    favorites: 'Favorites',
    noAdsPosted: 'No ads posted yet',
    startSelling: 'Start selling by posting your first ad',
    postFirstAd: 'Post Your First Ad',
    noFavorites: 'No favorites yet',
    saveAdsHere: "Save ads you're interested in to view them here",
    browseAds: 'Browse Ads',
    active: 'Active',
    inactive: 'Inactive',
    
    // Conditions
    new: 'New',
    likeNew: 'Like New',
    excellent: 'Excellent',
    good: 'Good',
    fair: 'Fair',
    
    // Sort options
    sortByLatest: 'Sort by: Latest',
    priceLowToHigh: 'Price: Low to High',
    priceHighToLow: 'Price: High to Low',
    mostPopular: 'Most Popular',
    
    // CTA
    gotSomethingToSell: 'Got something to sell?',
    postAdCTA: 'Post your ad for free and reach thousands of potential buyers',
    postAdNow: 'Post Your Ad Now',
    
    // Footer
    trustedMarketplace: 'Your trusted marketplace for buying and selling everything locally.',
    forBuyers: 'For Buyers',
    howToBuy: 'How to Buy',
    safetyTips: 'Safety Tips',
    paymentMethods: 'Payment Methods',
    forSellers: 'For Sellers',
    howToSell: 'How to Sell',
    pricingGuide: 'Pricing Guide',
    proFeatures: 'Pro Features',
    support: 'Support',
    helpCenter: 'Help Center',
    contactUs: 'Contact Us',
    reportIssue: 'Report Issue',
    allRightsReserved: 'All rights reserved.',
    cookiePolicy: 'Cookie Policy',
    
    // Messages
    addedToFavorites: 'Added to favorites',
    removedFromFavorites: 'Removed from favorites',
    adSavedToFavorites: 'Ad saved to your favorites',
    adRemovedFromFavorites: 'Ad removed from favorites',
    error: 'Error',
    success: 'Success!',
    adPostedSuccessfully: 'Your ad has been posted successfully.',
    welcomeBack: 'Welcome back!',
    loginSuccessful: 'You have been logged in successfully.',
    loginFailed: 'Login failed',
    accountCreated: 'Account created!',
    accountCreatedSuccessfully: 'Your account has been created successfully. Please sign in.',
    registrationFailed: 'Registration failed',
    comingSoon: 'Coming soon',
    
    // Comments
    comments: 'Comments',
    writeComment: 'Write a comment...',
    postComment: 'Post Comment',
    postingComment: 'Posting...',
    reply: 'Reply',
    delete: 'Delete',
    replyingToComment: 'Replying to comment',
    noComments: 'No comments yet. Be the first to comment!',
    confirmDeleteComment: 'Are you sure you want to delete this comment?',
    
    // Language
    language: 'Language',
    english: 'English',
    russian: 'Русский',
  },
  ru: {
    // Navigation
    home: 'Главная',
    myAds: 'Мои объявления',
    help: 'Помощь',
    postAd: 'Подать объявление',
    login: 'Войти',
    register: 'Регистрация',
    profile: 'Профиль',
    
    // Hero section
    heroTitle: 'Найдите все, что вам нужно',
    heroSubtitle: 'Покупайте и продавайте с уверенностью в вашем местном сообществе',
    searchPlaceholder: 'Что вы ищете?',
    allCategories: 'Все категории',
    locationPlaceholder: 'Местоположение',
    searchButton: 'Поиск',
    
    // Categories
    popularCategories: 'Популярные категории',
    electronics: 'Электроника',
    vehicles: 'Транспорт',
    homeGarden: 'Дом и сад',
    fashion: 'Мода',
    sportsRecreation: 'Спорт и отдых',
    jobs: 'Работа',
    services: 'Услуги',
    booksEducation: 'Книги и образование',
    
    // Ads
    featuredAds: 'Рекомендуемые объявления',
    searchResults: 'Результаты поиска',
    noAdsFound: 'Объявления не найдены',
    adjustSearchCriteria: 'Попробуйте изменить критерии поиска',
    loadMore: 'Загрузить еще',
    views: 'просмотров',
    ago: 'назад',
    justNow: 'Только что',
    hoursAgo: 'часов назад',
    daysAgo: 'дней назад',
    recently: 'Недавно',
    
    // Ad details
    backToListings: 'Назад к объявлениям',
    noImage: 'Изображение недоступно',
    share: 'Поделиться',
    callSeller: 'Позвонить продавцу',
    message: 'Написать',
    description: 'Описание',
    details: 'Детали',
    condition: 'Состояние',
    location: 'Местоположение',
    posted: 'Опубликовано',
    sellerInformation: 'Информация о продавце',
    memberSince: 'Участник с',
    reviews: 'отзывов',
    
    // Post ad
    postYourAd: 'Подать объявление',
    adTitle: 'Заголовок объявления',
    enterTitle: 'Введите описательный заголовок',
    category: 'Категория',
    selectCategory: 'Выберите категорию',
    price: 'Цена',
    selectCondition: 'Выберите состояние',
    enterDescription: 'Опишите ваш товар подробно...',
    photos: 'Фотографии',
    dragDropPhotos: 'Перетащите фотографии сюда или нажмите для выбора',
    chooseFiles: 'Выбрать файлы',
    enterLocation: 'Введите ваше местоположение',
    agreeToTerms: 'Я согласен с',
    termsOfService: 'Условиями обслуживания',
    privacyPolicy: 'Политикой конфиденциальности',
    cancel: 'Отмена',
    postingAd: 'Публикация...',
    
    // Auth
    signIn: 'Вход',
    createAccount: 'Создать аккаунт',
    continueWithGoogle: 'Продолжить с Google',
    continueWithFacebook: 'Продолжить с Facebook',
    or: 'или',
    email: 'Email',
    password: 'Пароль',
    confirmPassword: 'Подтвердите пароль',
    fullName: 'Полное имя',
    username: 'Имя пользователя',
    rememberMe: 'Запомнить меня',
    forgotPassword: 'Забыли пароль?',
    signingIn: 'Вход...',
    dontHaveAccount: 'Нет аккаунта?',
    signUp: 'Зарегистрироваться',
    alreadyHaveAccount: 'Уже есть аккаунт?',
    creatingAccount: 'Создание аккаунта...',
    enterEmail: 'Введите ваш email',
    enterPassword: 'Введите ваш пароль',
    createPassword: 'Создайте пароль',
    confirmYourPassword: 'Подтвердите ваш пароль',
    enterFullName: 'Введите ваше полное имя',
    chooseUsername: 'Выберите имя пользователя',
    
    // Profile
    editProfile: 'Редактировать профиль',
    activeAds: 'Активные объявления',
    totalViews: 'Всего просмотров',
    favorites: 'Избранное',
    noAdsPosted: 'Объявления еще не размещены',
    startSelling: 'Начните продавать, разместив ваше первое объявление',
    postFirstAd: 'Разместить первое объявление',
    noFavorites: 'Пока нет избранного',
    saveAdsHere: 'Сохраняйте интересные объявления, чтобы просматривать их здесь',
    browseAds: 'Просмотреть объявления',
    active: 'Активно',
    inactive: 'Неактивно',
    
    // Conditions
    new: 'Новое',
    likeNew: 'Как новое',
    excellent: 'Отличное',
    good: 'Хорошее',
    fair: 'Удовлетворительное',
    
    // Sort options
    sortByLatest: 'Сортировка: Новые',
    priceLowToHigh: 'Цена: По возрастанию',
    priceHighToLow: 'Цена: По убыванию',
    mostPopular: 'Самые популярные',
    
    // CTA
    gotSomethingToSell: 'Есть что продать?',
    postAdCTA: 'Разместите объявление бесплатно и привлеките тысячи потенциальных покупателей',
    postAdNow: 'Разместить объявление сейчас',
    
    // Footer
    trustedMarketplace: 'Ваша надежная площадка для покупки и продажи всего локально.',
    forBuyers: 'Для покупателей',
    howToBuy: 'Как покупать',
    safetyTips: 'Советы по безопасности',
    paymentMethods: 'Способы оплаты',
    forSellers: 'Для продавцов',
    howToSell: 'Как продавать',
    pricingGuide: 'Руководство по ценам',
    proFeatures: 'Pro возможности',
    support: 'Поддержка',
    helpCenter: 'Центр помощи',
    contactUs: 'Связаться с нами',
    reportIssue: 'Сообщить о проблеме',
    allRightsReserved: 'Все права защищены.',
    cookiePolicy: 'Политика cookie',
    
    // Messages
    addedToFavorites: 'Добавлено в избранное',
    removedFromFavorites: 'Удалено из избранного',
    adSavedToFavorites: 'Объявление сохранено в избранное',
    adRemovedFromFavorites: 'Объявление удалено из избранного',
    error: 'Ошибка',
    success: 'Успешно!',
    adPostedSuccessfully: 'Ваше объявление успешно размещено.',
    welcomeBack: 'Добро пожаловать!',
    loginSuccessful: 'Вы успешно вошли в систему.',
    loginFailed: 'Ошибка входа',
    accountCreated: 'Аккаунт создан!',
    accountCreatedSuccessfully: 'Ваш аккаунт успешно создан. Пожалуйста, войдите.',
    registrationFailed: 'Ошибка регистрации',
    comingSoon: 'Скоро',
    
    // Comments
    comments: 'Комментарии',
    writeComment: 'Написать комментарий...',
    postComment: 'Опубликовать',
    postingComment: 'Публикуем...',
    reply: 'Ответить',
    delete: 'Удалить',
    replyingToComment: 'Ответ на комментарий',
    noComments: 'Пока нет комментариев. Будьте первым!',
    confirmDeleteComment: 'Вы уверены, что хотите удалить этот комментарий?',
    
    // Language
    language: 'Язык',
    english: 'English',
    russian: 'Русский',
  },
};