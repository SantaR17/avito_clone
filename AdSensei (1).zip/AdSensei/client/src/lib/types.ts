export interface SearchParams {
  search?: string;
  categoryId?: string;
  location?: string;
  sortBy?: 'latest' | 'price-low' | 'price-high' | 'popular';
}

export interface AdWithSeller {
  id: string;
  title: string;
  description: string;
  price: string;
  condition: string;
  categoryId: string;
  location: string;
  images: string[];
  featured: boolean;
  active: boolean;
  views: number;
  createdAt: Date;
  seller: {
    id: string;
    username: string;
    fullName: string;
    avatar: string | null;
    rating: string;
    reviewCount: number;
  };
}
