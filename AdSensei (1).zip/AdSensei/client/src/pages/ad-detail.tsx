import { useParams, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Phone, Mail, MapPin, Eye, Clock, ArrowLeft, Share } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import CommentsSection from "@/components/comments-section";
import type { Ad, User } from "@shared/schema";

export default function AdDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: ad, isLoading } = useQuery<Ad>({
    queryKey: ["/api/ads", id],
    enabled: !!id,
  });

  const { data: seller } = useQuery<Omit<User, 'password'>>({
    queryKey: ["/api/users", ad?.sellerId],
    enabled: !!ad?.sellerId,
  });

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      // For demo purposes, using a hardcoded user ID
      const userId = "user1";
      await apiRequest("POST", "/api/favorites", { userId, adId: id });
    },
    onSuccess: () => {
      toast({
        title: "Added to favorites",
        description: "Ad saved to your favorites",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add to favorites",
        variant: "destructive",
      });
    },
  });

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(price));
  };

  const getTimeAgo = (date: Date | null) => {
    if (!date) return "Recently";
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-32 mb-6"></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="h-80 bg-muted rounded-xl"></div>
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-20 bg-muted rounded-lg"></div>
                  ))}
                </div>
              </div>
              <div className="space-y-6">
                <div className="h-12 bg-muted rounded w-3/4"></div>
                <div className="h-24 bg-muted rounded"></div>
                <div className="h-32 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!ad) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Ad not found</h1>
          <p className="text-muted-foreground mb-4">The ad you're looking for doesn't exist.</p>
          <Link href="/">
            <Button>Go back home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link href="/" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6" data-testid="link-back">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to listings
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Image Gallery */}
          <div>
            <div className="bg-muted rounded-xl mb-4 h-80 flex items-center justify-center">
              {ad.images && ad.images[0] ? (
                <img 
                  src={ad.images[0]} 
                  alt={ad.title}
                  className="max-w-full max-h-full object-contain rounded-xl"
                  data-testid="img-main"
                />
              ) : (
                <span className="text-muted-foreground">No image available</span>
              )}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {ad.images && ad.images.slice(0, 4).map((image, index) => (
                <div key={index} className="bg-muted rounded-lg h-20 cursor-pointer overflow-hidden">
                  <img 
                    src={image} 
                    alt={`${ad.title} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
              {Array.from({ length: Math.max(0, 4 - (ad.images?.length || 0)) }).map((_, index) => (
                <div key={`placeholder-${index}`} className="bg-muted rounded-lg h-20"></div>
              ))}
            </div>
          </div>

          {/* Ad Details */}
          <div>
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-3xl font-bold" data-testid="text-title">{ad.title}</h1>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="icon" data-testid="button-share">
                    <Share className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => favoriteMutation.mutate()}
                    disabled={favoriteMutation.isPending}
                    data-testid="button-favorite"
                  >
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center space-x-4 text-muted-foreground mb-4">
                <span className="flex items-center">
                  <MapPin className="w-4 h-4 mr-1" />
                  {ad.location}
                </span>
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  {getTimeAgo(ad.createdAt)}
                </span>
                <span className="flex items-center">
                  <Eye className="w-4 h-4 mr-1" />
                  {ad.views} views
                </span>
              </div>

              <div className="flex items-center justify-between mb-6">
                <span className="text-4xl font-bold text-primary" data-testid="text-price">
                  {formatPrice(ad.price)}
                </span>
                <Badge variant="secondary">{ad.condition}</Badge>
              </div>

              <div className="flex space-x-2 mb-6">
                <Button className="gradient-bg text-primary-foreground flex-1" data-testid="button-call">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Seller
                </Button>
                <Button variant="outline" className="flex-1" data-testid="button-message">
                  <Mail className="w-4 h-4 mr-2" />
                  Message
                </Button>
              </div>
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground whitespace-pre-wrap" data-testid="text-description">
                    {ad.description}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2">Details</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Condition:</span> {ad.condition}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Location:</span> {ad.location}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Posted:</span> {getTimeAgo(ad.createdAt)}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Views:</span> {ad.views}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {seller && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-2">Seller Information</h3>
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-primary-foreground font-semibold">
                        {seller.avatar || seller.fullName.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium" data-testid="text-seller-name">
                          {seller.fullName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Member since {seller.createdAt ? new Date(seller.createdAt).getFullYear() : 'Recently'}
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="flex text-yellow-400 mr-2">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <span key={i}>★</span>
                            ))}
                          </div>
                          <span className="text-muted-foreground">
                            {seller.rating} ({seller.reviewCount} reviews)
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
          
          {/* Comments Section */}
          <CommentsSection adId={id!} />
        </div>
      </div>
    </div>
  );
}
