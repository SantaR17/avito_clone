import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Grid3X3, List } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import HeroSection from "@/components/hero-section";
import CategoriesGrid from "@/components/categories-grid";
import AdCard from "@/components/ad-card";
import type { Ad } from "@shared/schema";
import type { SearchParams } from "@/lib/types";

export default function Home() {
  const [searchParams, setSearchParams] = useState<SearchParams>({});
  const [sortBy, setSortBy] = useState<string>("latest");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const { t } = useLanguage();

  const { data: ads = [], isLoading } = useQuery<Ad[]>({
    queryKey: ["/api/ads", searchParams],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchParams.search) params.append("search", searchParams.search);
      if (searchParams.categoryId) params.append("categoryId", searchParams.categoryId);
      if (searchParams.location) params.append("location", searchParams.location);
      
      const response = await fetch(`/api/ads?${params}`);
      if (!response.ok) throw new Error("Failed to fetch ads");
      return response.json();
    },
  });

  const handleSearch = (params: SearchParams) => {
    setSearchParams(params);
  };

  const handleCategorySelect = (categoryId: string) => {
    setSearchParams(prev => ({ ...prev, categoryId }));
  };

  const sortedAds = [...ads].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return parseFloat(a.price) - parseFloat(b.price);
      case "price-high":
        return parseFloat(b.price) - parseFloat(a.price);
      case "popular":
        return (b.views || 0) - (a.views || 0);
      default: // latest
        return (b.createdAt ? new Date(b.createdAt).getTime() : 0) - (a.createdAt ? new Date(a.createdAt).getTime() : 0);
    }
  });

  return (
    <div className="min-h-screen">
      <HeroSection onSearch={handleSearch} />
      <CategoriesGrid onCategorySelect={handleCategorySelect} />
      
      {/* Featured Ads Section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-2xl font-bold">
              {searchParams.search || searchParams.categoryId || searchParams.location 
                ? t.searchResults 
                : t.featuredAds
              }
            </h3>
            <div className="flex items-center space-x-4">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48" data-testid="select-sort">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="latest">{t.sortLatest}</SelectItem>
                  <SelectItem value="price-low">{t.sortPriceLow}</SelectItem>
                  <SelectItem value="price-high">{t.sortPriceHigh}</SelectItem>
                  <SelectItem value="popular">{t.sortPopular}</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex border border-border rounded-lg">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  data-testid="button-grid-view"
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  data-testid="button-list-view"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-card rounded-xl shadow-sm animate-pulse">
                  <div className="w-full h-48 bg-muted rounded-t-xl"></div>
                  <div className="p-4 space-y-3">
                    <div className="h-6 bg-muted rounded w-20"></div>
                    <div className="h-4 bg-muted rounded w-3/4"></div>
                    <div className="h-3 bg-muted rounded w-full"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : sortedAds.length === 0 ? (
            <div className="text-center py-12">
              <h4 className="text-lg font-semibold mb-2">{t.noAdsFound}</h4>
              <p className="text-muted-foreground">{t.adjustSearchCriteria}</p>
            </div>
          ) : (
            <div className={viewMode === "grid" 
              ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              : "space-y-4"
            }>
              {sortedAds.map((ad) => (
                <AdCard key={ad.id} ad={ad} />
              ))}
            </div>
          )}

          {/* Load More Button */}
          {sortedAds.length > 0 && (
            <div className="text-center mt-8">
              <Button variant="outline" className="px-8 py-3" data-testid="button-load-more">
                {t.loadMoreAds}
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Post Ad CTA Section */}
      <section className="gradient-bg py-16 text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold mb-4">{t.gotSomethingToSell}</h3>
          <p className="text-xl mb-8 opacity-90">{t.postAdFree}</p>
          <Button 
            asChild
            className="bg-card text-foreground px-8 py-4 rounded-xl font-semibold hover:bg-opacity-90 transition-colors"
          >
            <a href="/post-ad" data-testid="button-post-ad-cta">
              <span className="mr-2">+</span>
              {t.postAdNow}
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="gradient-bg p-2 rounded-lg">
                  <span className="text-primary-foreground font-bold">C</span>
                </div>
                <h4 className="font-bold text-lg">ClassiMarket</h4>
              </div>
              <p className="text-muted-foreground">Your trusted marketplace for buying and selling everything locally.</p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">For Buyers</h5>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">How to Buy</a></li>
                <li><a href="#" className="hover:text-foreground">Safety Tips</a></li>
                <li><a href="#" className="hover:text-foreground">Payment Methods</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">For Sellers</h5>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">How to Sell</a></li>
                <li><a href="#" className="hover:text-foreground">Pricing Guide</a></li>
                <li><a href="#" className="hover:text-foreground">Pro Features</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground">Contact Us</a></li>
                <li><a href="#" className="hover:text-foreground">Report Issue</a></li>
              </ul>
            </div>
          </div>
          <hr className="border-border my-8" />
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-muted-foreground">&copy; 2024 ClassiMarket. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-muted-foreground hover:text-foreground">Privacy Policy</a>
              <a href="#" className="text-muted-foreground hover:text-foreground">Terms of Service</a>
              <a href="#" className="text-muted-foreground hover:text-foreground">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
