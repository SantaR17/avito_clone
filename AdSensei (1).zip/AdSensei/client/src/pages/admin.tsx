import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, ShoppingBag, MessageCircle, Trash2, Eye, Ban, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Ad, User } from "@shared/schema";

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get admin data
  const { data: users = [], isLoading: loadingUsers } = useQuery<Omit<User, 'password'>[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: ads = [], isLoading: loadingAds } = useQuery<Ad[]>({
    queryKey: ["/api/admin/ads"],
  });

  // Delete ad mutation
  const deleteAdMutation = useMutation({
    mutationFn: (adId: string) => apiRequest(`/api/ads/${adId}`, "DELETE"),
    onSuccess: () => {
      toast({
        title: "Ad deleted",
        description: "The ad has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ads"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete ad.",
        variant: "destructive",
      });
    },
  });

  // Toggle ad status mutation
  const toggleAdMutation = useMutation({
    mutationFn: ({ adId, active }: { adId: string; active: boolean }) => 
      apiRequest(`/api/ads/${adId}`, "PATCH", { active }),
    onSuccess: () => {
      toast({
        title: "Ad updated",
        description: "Ad status has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ads"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update ad status.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteAd = (adId: string, title: string) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      deleteAdMutation.mutate(adId);
    }
  };

  const handleToggleAd = (adId: string, currentStatus: boolean) => {
    toggleAdMutation.mutate({ adId, active: !currentStatus });
  };

  const formatPrice = (price: string) => {
    // Check if price contains Cyrillic characters (Russian prices)
    if (/[а-яё]/i.test(price)) {
      return `₽${parseFloat(price).toLocaleString('ru-RU')}`;
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(price));
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "Unknown";
    return new Date(date).toLocaleDateString();
  };

  // Stats calculations
  const totalUsers = users.length;
  const totalAds = ads.length;
  const activeAds = ads.filter(ad => ad.active).length;
  const inactiveAds = ads.filter(ad => !ad.active).length;
  const totalViews = ads.reduce((sum, ad) => sum + (ad.views || 0), 0);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Admin Panel</h1>
          <p className="text-muted-foreground mt-2">Manage users, ads, and platform content</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">Users</TabsTrigger>
            <TabsTrigger value="ads" data-testid="tab-ads">Ads</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-users">{totalUsers}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Ads</CardTitle>
                  <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-ads">{totalAds}</div>
                  <p className="text-xs text-muted-foreground">
                    {activeAds} active, {inactiveAds} inactive
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Views</CardTitle>
                  <Eye className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-views">{totalViews.toLocaleString()}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Comments</CardTitle>
                  <MessageCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-comments">0</div>
                  <p className="text-xs text-muted-foreground">
                    Comments system active
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {ads.slice(0, 5).map((ad) => (
                    <div key={ad.id} className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
                        <ShoppingBag className="w-5 h-5 text-primary-foreground" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{ad.title}</p>
                        <p className="text-xs text-muted-foreground">
                          Posted {formatDate(ad.createdAt)} • {ad.views} views
                        </p>
                      </div>
                      <Badge variant={ad.active ? "default" : "secondary"}>
                        {ad.active ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingUsers ? (
                  <div className="space-y-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-12 bg-muted rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Rating</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-primary-foreground text-xs font-semibold">
                                {user.avatar || user.fullName.substring(0, 2).toUpperCase()}
                              </div>
                              <div>
                                <div className="font-medium">{user.fullName}</div>
                                <div className="text-sm text-muted-foreground">@{user.username}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                              {user.role || 'user'}
                            </Badge>
                          </TableCell>
                          <TableCell>{formatDate(user.createdAt)}</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <span className="text-yellow-400 mr-1">★</span>
                              {user.rating} ({user.reviewCount})
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm" data-testid={`button-view-user-${user.id}`}>
                                <Eye className="w-3 h-3" />
                              </Button>
                              {user.role !== 'admin' && (
                                <Button variant="outline" size="sm" data-testid={`button-ban-user-${user.id}`}>
                                  <Ban className="w-3 h-3" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ads" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Ad Management</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingAds ? (
                  <div className="space-y-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-16 bg-muted rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Ad</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Views</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Posted</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ads.map((ad) => (
                        <TableRow key={ad.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{ad.title}</div>
                              <div className="text-sm text-muted-foreground truncate max-w-xs">
                                {ad.description}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{formatPrice(ad.price)}</TableCell>
                          <TableCell>{ad.location}</TableCell>
                          <TableCell>{ad.views || 0}</TableCell>
                          <TableCell>
                            <Badge variant={ad.active ? "default" : "secondary"}>
                              {ad.active ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell>{formatDate(ad.createdAt)}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleToggleAd(ad.id, ad.active)}
                                disabled={toggleAdMutation.isPending}
                                data-testid={`button-toggle-ad-${ad.id}`}
                              >
                                {ad.active ? <Ban className="w-3 h-3" /> : <CheckCircle className="w-3 h-3" />}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteAd(ad.id, ad.title)}
                                disabled={deleteAdMutation.isPending}
                                data-testid={`button-delete-ad-${ad.id}`}
                              >
                                <Trash2 className="w-3 h-3 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}