import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Eye, Star } from "lucide-react";
import { Link } from "wouter";
import AdCard from "@/components/ad-card";
import type { Ad, User } from "@shared/schema";

export default function Profile() {
  const [activeTab, setActiveTab] = useState("my-ads");
  
  // For demo purposes, using hardcoded user ID
  const userId = "user1";

  const { data: user } = useQuery<Omit<User, 'password'>>({
    queryKey: ["/api/users", userId],
  });

  const { data: userAds = [] } = useQuery<Ad[]>({
    queryKey: ["/api/ads", { sellerId: userId }],
    queryFn: async () => {
      const response = await fetch(`/api/ads?sellerId=${userId}`);
      if (!response.ok) throw new Error("Failed to fetch user ads");
      return response.json();
    },
  });

  const { data: favorites = [] } = useQuery({
    queryKey: ["/api/favorites", userId],
  });

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(parseFloat(price));
  };

  const getTimeAgo = (date: Date | null) => {
    if (!date) return "Recently";
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-semibold mb-4">Please Login</h2>
            <p className="text-muted-foreground mb-4">You need to be logged in to view your profile.</p>
            <Link href="/login">
              <Button className="w-full">Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-6">
              <div className="w-20 h-20 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-primary-foreground text-2xl font-bold">
                {user.avatar || user.fullName.substring(0, 2).toUpperCase()}
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold mb-2" data-testid="text-username">{user.fullName}</h1>
                <p className="text-muted-foreground mb-2">@{user.username}</p>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="font-medium">{user.rating}</span>
                    <span className="text-muted-foreground ml-1">({user.reviewCount} reviews)</span>
                  </div>
                  <Badge variant="secondary">Member since {user.createdAt ? new Date(user.createdAt).getFullYear() : 'Recently'}</Badge>
                </div>
              </div>
              <Button variant="outline" data-testid="button-edit-profile">
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="text-2xl font-bold text-primary">{userAds.length}</div>
              <div className="text-muted-foreground">Active Ads</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="text-2xl font-bold text-primary">
                {userAds.reduce((total, ad) => total + (ad.views || 0), 0)}
              </div>
              <div className="text-muted-foreground">Total Views</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="text-2xl font-bold text-primary">{Array.isArray(favorites) ? favorites.length : 0}</div>
              <div className="text-muted-foreground">Favorites</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="my-ads" data-testid="tab-my-ads">My Ads</TabsTrigger>
            <TabsTrigger value="favorites" data-testid="tab-favorites">Favorites</TabsTrigger>
          </TabsList>

          <TabsContent value="my-ads" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">My Ads ({userAds.length})</h2>
              <Link href="/post-ad">
                <Button className="gradient-bg text-primary-foreground" data-testid="button-post-new-ad">
                  <Plus className="w-4 h-4 mr-2" />
                  Post New Ad
                </Button>
              </Link>
            </div>

            {userAds.length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center py-12">
                  <h3 className="text-lg font-semibold mb-2">No ads posted yet</h3>
                  <p className="text-muted-foreground mb-4">Start selling by posting your first ad</p>
                  <Link href="/post-ad">
                    <Button className="gradient-bg text-primary-foreground">
                      <Plus className="w-4 h-4 mr-2" />
                      Post Your First Ad
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {userAds.map((ad) => (
                  <Card key={ad.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex items-center space-x-4">
                        <div className="w-20 h-20 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                          {ad.images && ad.images[0] ? (
                            <img 
                              src={ad.images[0]} 
                              alt={ad.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                              No image
                            </div>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-lg mb-1 truncate">{ad.title}</h3>
                          <p className="text-2xl font-bold text-primary mb-2">{formatPrice(ad.price)}</p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span className="flex items-center">
                              <Eye className="w-4 h-4 mr-1" />
                              {ad.views || 0} views
                            </span>
                            <span>{getTimeAgo(ad.createdAt)}</span>
                            <Badge variant={ad.active ? "default" : "secondary"}>
                              {ad.active ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button variant="outline" size="icon" data-testid={`button-edit-${ad.id}`}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="icon" data-testid={`button-delete-${ad.id}`}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="favorites" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Favorites ({favorites.length})</h2>
            </div>

            {!Array.isArray(favorites) || favorites.length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center py-12">
                  <h3 className="text-lg font-semibold mb-2">No favorites yet</h3>
                  <p className="text-muted-foreground mb-4">Save ads you're interested in to view them here</p>
                  <Link href="/">
                    <Button variant="outline">Browse Ads</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* This would show favorited ads - for demo showing empty state */}
                <p className="col-span-full text-center text-muted-foreground">
                  Favorite ads would appear here
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
