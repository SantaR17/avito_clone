import { type User, type InsertUser, type Category, type InsertCategory, type Ad, type InsertAd, type Favorite, type InsertFavorite, type Comment, type InsertComment, type CommentWithUser } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Ads
  getAds(params?: { categoryId?: string; search?: string; location?: string; sellerId?: string }): Promise<Ad[]>;
  getAd(id: string): Promise<Ad | undefined>;
  createAd(ad: InsertAd & { sellerId: string }): Promise<Ad>;
  updateAd(id: string, updates: Partial<Ad>): Promise<Ad | undefined>;
  deleteAd(id: string): Promise<boolean>;
  incrementViews(id: string): Promise<void>;

  // Favorites
  getFavorites(userId: string): Promise<Favorite[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: string, adId: string): Promise<boolean>;
  isFavorite(userId: string, adId: string): Promise<boolean>;

  // Comments
  getComments(adId: string): Promise<CommentWithUser[]>;
  createComment(comment: InsertComment & { userId: string }): Promise<Comment>;
  deleteComment(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private categories: Map<string, Category>;
  private ads: Map<string, Ad>;
  private favorites: Map<string, Favorite>;
  private comments: Map<string, Comment>;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.ads = new Map();
    this.favorites = new Map();
    this.comments = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed categories
    const sampleCategories: Category[] = [
      { id: "1", name: "Electronics", icon: "laptop", description: "Phones, computers, gadgets", adCount: 156 },
      { id: "2", name: "Vehicles", icon: "car", description: "Cars, motorcycles, boats", adCount: 89 },
      { id: "3", name: "Home & Garden", icon: "home", description: "Furniture, appliances, tools", adCount: 234 },
      { id: "4", name: "Fashion", icon: "shirt", description: "Clothing, shoes, accessories", adCount: 67 },
      { id: "5", name: "Sports & Recreation", icon: "dumbbell", description: "Fitness, outdoor gear, bikes", adCount: 78 },
      { id: "6", name: "Jobs", icon: "briefcase", description: "Employment opportunities", adCount: 45 },
      { id: "7", name: "Services", icon: "wrench", description: "Professional services", adCount: 123 },
      { id: "8", name: "Books & Education", icon: "book", description: "Books, courses, education", adCount: 34 },
    ];

    sampleCategories.forEach(category => this.categories.set(category.id, category));

    // Seed sample users
    const sampleUsers: User[] = [
      {
        id: "user1",
        username: "johndoe",
        email: "john@example.com",
        password: "hashed_password",
        fullName: "John Doe",
        avatar: "JD",
        rating: "4.8",
        reviewCount: 124,
        role: "admin",
        createdAt: new Date(),
      },
      {
        id: "user2",
        username: "alexgamer",
        email: "alex@example.com",
        password: "hashed_password",
        fullName: "Алексей Петров",
        avatar: "АП",
        rating: "4.9",
        reviewCount: 89,
        role: "user",
        createdAt: new Date(),
      },
      {
        id: "user3",
        username: "dmitriy_tech",
        email: "dmitriy@example.com",
        password: "hashed_password",
        fullName: "Дмитрий Иванов",
        avatar: "ДИ",
        rating: "4.7",
        reviewCount: 156,
        role: "user",
        createdAt: new Date(),
      },
      {
        id: "user4",
        username: "marina_uu",
        email: "marina@example.com",
        password: "hashed_password",
        fullName: "Марина Сергеева",
        avatar: "МС",
        rating: "4.6",
        reviewCount: 67,
        role: "user",
        createdAt: new Date(),
      },
      {
        id: "user5",
        username: "gamer_kyzyl",
        email: "gamer@example.com",
        password: "hashed_password",
        fullName: "Батbayar Монгуш",
        avatar: "БМ",
        rating: "4.8",
        reviewCount: 34,
        role: "user",
        createdAt: new Date(),
      },
    ];
    
    sampleUsers.forEach(user => this.users.set(user.id, user));

    // Seed sample ads
    const sampleAds: Ad[] = [
      {
        id: "1",
        title: "iPhone 14 Pro Max",
        description: "Excellent condition iPhone 14 Pro Max with all original accessories. Barely used, perfect for upgrade. Includes charger, earphones, and original box.",
        price: "899.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user1",
        location: "New York, NY",
        images: ["https://images.unsplash.com/photo-1592750475338-74b7b21085ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 124,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        id: "2",
        title: "Gaming Laptop RTX 3060",
        description: "High-performance gaming laptop with RTX 3060, 16GB RAM, perfect for gaming and work. Runs all modern games at high settings.",
        price: "1299.00",
        condition: "Like New",
        categoryId: "1",
        sellerId: "user1",
        location: "Los Angeles, CA",
        images: ["https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 89,
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      },
      {
        id: "3",
        title: "Vintage Leather Sofa",
        description: "Beautiful vintage leather sofa in excellent condition. Perfect centerpiece for any living room. Genuine leather, very comfortable.",
        price: "450.00",
        condition: "Good",
        categoryId: "3",
        sellerId: "user1",
        location: "Chicago, IL",
        images: ["https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 67,
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
      },
      {
        id: "4",
        title: "Professional Road Bike",
        description: "Professional road bike, lightweight carbon frame, perfect for cycling enthusiasts. Well maintained, ready to ride.",
        price: "850.00",
        condition: "Excellent",
        categoryId: "5",
        sellerId: "user1",
        location: "Seattle, WA",
        images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 45,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        id: "5",
        title: "Swiss Luxury Watch",
        description: "Luxury Swiss made watch, automatic movement, comes with original box and papers. Perfect condition, barely worn.",
        price: "2100.00",
        condition: "Like New",
        categoryId: "4",
        sellerId: "user1",
        location: "Miami, FL",
        images: ["https://images.unsplash.com/photo-1524592094714-0f0654e20314?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 156,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        id: "6",
        title: "Dining Table Set",
        description: "Beautiful wooden dining table with 4 chairs, perfect for family dinners. Solid wood construction, excellent craftsmanship.",
        price: "320.00",
        condition: "Good",
        categoryId: "3",
        sellerId: "user1",
        location: "Austin, TX",
        images: ["https://images.unsplash.com/photo-1549497538-303791108f95?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 78,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      },
      {
        id: "7",
        title: "Canon 50mm f/1.4 Lens",
        description: "Professional 50mm f/1.4 lens for Canon, perfect for portraits and low light photography. Excellent optics, no scratches.",
        price: "680.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user1",
        location: "Denver, CO",
        images: ["https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 92,
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
      },
      {
        id: "8",
        title: "Home Gym Equipment",
        description: "Home gym setup with adjustable dumbbells and bench. Great for home workouts. Includes various weight plates.",
        price: "200.00",
        condition: "Good",
        categoryId: "5",
        sellerId: "user1",
        location: "Phoenix, AZ",
        images: ["https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 34,
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
      },
      // NVIDIA Graphics Cards in Kyzyl and Ulan-Ude
      {
        id: "9",
        title: "GeForce RTX 4090 24GB",
        description: "Топовая видеокарта NVIDIA RTX 4090 с 24GB GDDR6X. Идеальна для 4K гейминга и работы с нейросетями. Состояние отличное, использовалась для майнинга всего 3 месяца. Есть гарантия.",
        price: "150000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user2",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 234,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        id: "10",
        title: "RTX 4080 SUPER 16GB MSI Gaming X",
        description: "MSI GeForce RTX 4080 SUPER Gaming X Trio 16GB. Отличная карта для всех современных игр в 4K. Тихая система охлаждения, RGB подсветка. В комплекте коробка и документы.",
        price: "120000.00",
        condition: "Like New",
        categoryId: "1",
        sellerId: "user3",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1518717758536-85ae29035b6d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 189,
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        id: "11",
        title: "GeForce RTX 4070 Ti SUPER",
        description: "NVIDIA RTX 4070 Ti SUPER 16GB. Отличное соотношение цена/качество. Тянет все игры в 1440p на ультрах. Покупал в DNS, есть чек. Продаю в связи с апгрейдом.",
        price: "85000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user4",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1587202372775-e229f172b9d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 156,
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      },
      {
        id: "12",
        title: "RTX 4060 Ti 16GB ASUS TUF Gaming",
        description: "ASUS TUF Gaming GeForce RTX 4060 Ti 16GB. Надёжная карта для 1440p гейминга. Отличное охлаждение TUF, работает тихо. Покупал для сына, но ему хватает встройки.",
        price: "65000.00",
        condition: "Like New",
        categoryId: "1",
        sellerId: "user5",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1558985250-c5c04a72b3e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 98,
        createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
      },
      {
        id: "13",
        title: "GeForce RTX 3080 10GB",
        description: "RTX 3080 Founders Edition 10GB. Классная карта, до сих пор актуальна. Играю в Cyberpunk 2077 на высоких в 1440p. Продаю из-за переезда.",
        price: "55000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user2",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1591488320449-011701bb6704?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 143,
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
      },
      {
        id: "14",
        title: "RTX 3070 Ti 8GB Gigabyte Eagle",
        description: "Gigabyte GeForce RTX 3070 Ti Eagle 8GB. Хорошая карта для Full HD и 1440p. Стабильно работает, никогда не перегревалась. Коробка и документы в наличии.",
        price: "48000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user3",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1571945849488-bb3b334d0ba1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 87,
        createdAt: new Date(Date.now() - 16 * 60 * 60 * 1000),
      },
      {
        id: "15",
        title: "GeForce GTX 1660 SUPER 6GB",
        description: "GTX 1660 SUPER 6GB GDDR6. Отличная бюджетная карта для 1080p гейминга. Все популярные игры идут на средних-высоких настройках. Продаю после апгрейда на RTX.",
        price: "25000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user4",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1555680202-c86f0e12f09d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 76,
        createdAt: new Date(Date.now() - 18 * 60 * 60 * 1000),
      },
      {
        id: "16",
        title: "RTX 4070 12GB EVGA FTW3",
        description: "EVGA GeForce RTX 4070 FTW3 Ultra Gaming 12GB. Мощная карта с отличным охлаждением. RGB подсветка, бесшумная работа. Использовал полгода, состояние как новая.",
        price: "75000.00",
        condition: "Like New",
        categoryId: "1",
        sellerId: "user5",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 134,
        createdAt: new Date(Date.now() - 20 * 60 * 60 * 1000),
      },
      {
        id: "17",
        title: "GeForce RTX 3060 12GB",
        description: "RTX 3060 12GB GDDR6. Золотая середина для современного гейминга. DLSS 3.0, ray tracing. Отлично подходит для киберспорта и AAA игр в Full HD.",
        price: "42000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user2",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 165,
        createdAt: new Date(Date.now() - 22 * 60 * 60 * 1000),
      },
      {
        id: "18",
        title: "GTX 1650 4GB Palit StormX",
        description: "Palit GeForce GTX 1650 StormX 4GB. Компактная карта для небольших корпусов. Идеальна для Counter-Strike, Dota 2, Valorant. Низкое энергопотребление.",
        price: "18000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user3",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 92,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      },
      {
        id: "19",
        title: "RTX 3090 24GB Founders Edition",
        description: "NVIDIA RTX 3090 Founders Edition 24GB. Флагманская карта прошлого поколения. 24GB памяти для работы с ИИ и рендеринга. Отличное состояние, не майнилась.",
        price: "95000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user4",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1587831990711-23ca6441447b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: true,
        active: true,
        views: 201,
        createdAt: new Date(Date.now() - 26 * 60 * 60 * 1000),
      },
      {
        id: "20",
        title: "GeForce RTX 2070 SUPER 8GB",
        description: "RTX 2070 SUPER 8GB GDDR6. Хорошая карта для 1440p гейминга. Поддержка RT и DLSS первого поколения. Стабильная работа, никаких проблем за 2 года использования.",
        price: "38000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user5",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1518717758536-85ae29035b6d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 117,
        createdAt: new Date(Date.now() - 28 * 60 * 60 * 1000),
      },
      {
        id: "21",
        title: "GTX 1080 Ti 11GB ASUS ROG STRIX",
        description: "ASUS ROG STRIX GTX 1080 Ti 11GB. Легендарная карта, до сих пор актуальна для Full HD и 1440p. RGB подсветка AURA Sync. Отличное охлаждение.",
        price: "35000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user2",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1591488320449-011701bb6704?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 156,
        createdAt: new Date(Date.now() - 30 * 60 * 60 * 1000),
      },
      {
        id: "22",
        title: "RTX 4060 8GB Gigabyte Windforce",
        description: "Gigabyte GeForce RTX 4060 Windforce OC 8GB. Новейшая архитектура Ada Lovelace. DLSS 3 Frame Generation. Энергоэффективная карта для Full HD гейминга.",
        price: "52000.00",
        condition: "Like New",
        categoryId: "1",
        sellerId: "user3",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1558985250-c5c04a72b3e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 89,
        createdAt: new Date(Date.now() - 32 * 60 * 60 * 1000),
      },
      {
        id: "23",
        title: "GeForce GTX 1070 8GB",
        description: "GTX 1070 8GB GDDR5. Проверенная временем карта. Отлично подходит для 1080p гейминга на высоких настройках. Продаю в связи с покупкой RTX.",
        price: "28000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user4",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1587202372775-e229f172b9d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 74,
        createdAt: new Date(Date.now() - 34 * 60 * 60 * 1000),
      },
      {
        id: "24",
        title: "RTX 3070 8GB ZOTAC Twin Edge",
        description: "ZOTAC GeForce RTX 3070 Twin Edge 8GB. Компактная двухслотовая карта. Отличная производительность в 1440p. Тихая работа, низкие температуры.",
        price: "50000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user5",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1571945849488-bb3b334d0ba1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 128,
        createdAt: new Date(Date.now() - 36 * 60 * 60 * 1000),
      },
      {
        id: "25",
        title: "GTX 1660 6GB MSI Ventus XS",
        description: "MSI GeForce GTX 1660 Ventus XS 6GB. Отличная бюджетная карта без излишеств. Справляется с современными играми в Full HD на средних настройках.",
        price: "22000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user2",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1555680202-c86f0e12f09d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 85,
        createdAt: new Date(Date.now() - 38 * 60 * 60 * 1000),
      },
      {
        id: "26",
        title: "RTX 2080 Ti 11GB",
        description: "GeForce RTX 2080 Ti 11GB GDDR6. Бывший флагман, до сих пор мощная карта. 11GB памяти, ray tracing первого поколения. Отличное состояние.",
        price: "58000.00",
        condition: "Excellent",
        categoryId: "1",
        sellerId: "user3",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 167,
        createdAt: new Date(Date.now() - 40 * 60 * 60 * 1000),
      },
      {
        id: "27",
        title: "GTX 1050 Ti 4GB Low Profile",
        description: "GTX 1050 Ti 4GB Low Profile. Идеальна для офисных ПК и HTPC. Не требует дополнительного питания. Отлично подходит для лёгких игр и видеомонтажа.",
        price: "15000.00",
        condition: "Good",
        categoryId: "1",
        sellerId: "user4",
        location: "Улан-Удэ, Бурятия",
        images: ["https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 67,
        createdAt: new Date(Date.now() - 42 * 60 * 60 * 1000),
      },
      {
        id: "28",
        title: "RTX 3050 8GB ASUS Dual",
        description: "ASUS Dual GeForce RTX 3050 8GB. Начальная RTX карта с поддержкой DLSS и RT. Хорошо подходит для киберспорта и некоторых AAA игр в Full HD.",
        price: "32000.00",
        condition: "Like New",
        categoryId: "1",
        sellerId: "user5",
        location: "Кызыл, Тыва",
        images: ["https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"],
        featured: false,
        active: true,
        views: 103,
        createdAt: new Date(Date.now() - 44 * 60 * 60 * 1000),
      },
    ];

    sampleAds.forEach(ad => this.ads.set(ad.id, ad));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      avatar: insertUser.avatar || null,
      rating: "0.00",
      reviewCount: 0,
      role: "user",
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = {
      ...insertCategory,
      id,
      description: insertCategory.description || null,
      adCount: 0,
    };
    this.categories.set(id, category);
    return category;
  }

  // Ad methods
  async getAds(params?: { categoryId?: string; search?: string; location?: string; sellerId?: string }): Promise<Ad[]> {
    let ads = Array.from(this.ads.values()).filter(ad => ad.active);

    if (params?.categoryId) {
      ads = ads.filter(ad => ad.categoryId === params.categoryId);
    }

    if (params?.search) {
      const searchTerm = params.search.toLowerCase();
      ads = ads.filter(ad => 
        ad.title.toLowerCase().includes(searchTerm) ||
        ad.description.toLowerCase().includes(searchTerm)
      );
    }

    if (params?.location) {
      ads = ads.filter(ad => ad.location.toLowerCase().includes(params.location!.toLowerCase()));
    }

    if (params?.sellerId) {
      ads = ads.filter(ad => ad.sellerId === params.sellerId);
    }

    return ads.sort((a, b) => (b.createdAt ? new Date(b.createdAt).getTime() : 0) - (a.createdAt ? new Date(a.createdAt).getTime() : 0));
  }

  async getAd(id: string): Promise<Ad | undefined> {
    return this.ads.get(id);
  }

  async createAd(adData: InsertAd & { sellerId: string }): Promise<Ad> {
    const id = randomUUID();
    const ad: Ad = {
      ...adData,
      id,
      images: adData.images || [],
      featured: false,
      active: true,
      views: 0,
      createdAt: new Date(),
    };
    this.ads.set(id, ad);
    return ad;
  }

  async updateAd(id: string, updates: Partial<Ad>): Promise<Ad | undefined> {
    const ad = this.ads.get(id);
    if (!ad) return undefined;
    const updatedAd = { ...ad, ...updates };
    this.ads.set(id, updatedAd);
    return updatedAd;
  }

  async deleteAd(id: string): Promise<boolean> {
    return this.ads.delete(id);
  }

  async incrementViews(id: string): Promise<void> {
    const ad = this.ads.get(id);
    if (ad && ad.views !== null) {
      ad.views++;
      this.ads.set(id, ad);
    }
  }

  // Favorite methods
  async getFavorites(userId: string): Promise<Favorite[]> {
    return Array.from(this.favorites.values()).filter(fav => fav.userId === userId);
  }

  async addFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const id = randomUUID();
    const favorite: Favorite = {
      ...insertFavorite,
      id,
      createdAt: new Date(),
    };
    this.favorites.set(id, favorite);
    return favorite;
  }

  async removeFavorite(userId: string, adId: string): Promise<boolean> {
    const favorite = Array.from(this.favorites.values()).find(
      fav => fav.userId === userId && fav.adId === adId
    );
    if (favorite) {
      return this.favorites.delete(favorite.id);
    }
    return false;
  }

  async isFavorite(userId: string, adId: string): Promise<boolean> {
    return Array.from(this.favorites.values()).some(
      fav => fav.userId === userId && fav.adId === adId
    );
  }

  // Comment methods
  async getComments(adId: string): Promise<CommentWithUser[]> {
    const comments = Array.from(this.comments.values())
      .filter(comment => comment.adId === adId)
      .sort((a, b) => (a.createdAt ? new Date(a.createdAt).getTime() : 0) - (b.createdAt ? new Date(b.createdAt).getTime() : 0));

    const commentsWithUsers: CommentWithUser[] = [];
    
    for (const comment of comments) {
      const user = this.users.get(comment.userId);
      if (user) {
        const commentWithUser: CommentWithUser = {
          ...comment,
          user: {
            id: user.id,
            username: user.username,
            fullName: user.fullName,
            avatar: user.avatar,
          },
          replies: [],
        };
        
        if (!comment.parentId) {
          // This is a top-level comment
          commentsWithUsers.push(commentWithUser);
        } else {
          // This is a reply, find its parent
          const parent = commentsWithUsers.find(c => c.id === comment.parentId);
          if (parent) {
            parent.replies = parent.replies || [];
            parent.replies.push(commentWithUser);
          }
        }
      }
    }
    
    return commentsWithUsers;
  }

  async createComment(commentData: InsertComment & { userId: string }): Promise<Comment> {
    const id = randomUUID();
    const comment: Comment = {
      ...commentData,
      id,
      parentId: commentData.parentId || null,
      createdAt: new Date(),
    };
    this.comments.set(id, comment);
    return comment;
  }

  async deleteComment(id: string): Promise<boolean> {
    return this.comments.delete(id);
  }
}

export const storage = new MemStorage();
